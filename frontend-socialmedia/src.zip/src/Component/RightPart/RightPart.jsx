import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

import SearchIcon from "@mui/icons-material/Search";
import Avatar from "@mui/material/Avatar";

const RightPart = ({ onUserSelect }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const navigate = useNavigate();

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    try {
      const accessToken = localStorage.getItem("access_token");
      const response = await axios.get(
        `http://localhost:8080/api/v1/users?keyword=${searchQuery}&page=1&size=5`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (response.data && response.data.Status === 200) {
        setSearchResults(response.data.Data.users);
      }
    } catch (error) {
      console.error("Lỗi khi tìm kiếm:", error);
    }
  };

  const handleUserClick = (user) => {
    navigate(`/homepage/profile/${user.id}`, {
      state: {
        from: "rightpart",
        username: user.username,
        userId: user.id,
      },
    });
    setSearchResults([]);
    setSearchQuery("");
  };

  return (
    <div className="py-5 sticky top-0 right-10">
      <div className="relative flex items-center">
        <form onSubmit={handleSearch} className="w-full">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="py-3 rounded-full text-gray-500 w-full pl-12"
            placeholder="Tìm kiếm người dùng..."
          />
          <button type="submit" className="absolute top-0 left-0 p-3 pt-3">
            <SearchIcon className="text-gray-500" />
          </button>
        </form>
      </div>

      {searchResults.length > 0 && (
        <div className="mt-4 bg-white rounded-lg shadow-lg p-4 absolute w-full z-50">
          {searchResults.map((user) => (
            <div
              key={user.id}
              onClick={() => handleUserClick(user)}
              className="flex items-center space-x-3 p-3 hover:bg-gray-100 rounded-lg cursor-pointer"
            >
              <Avatar
                alt={user.username}
                src={user.avatarUrl || "https://static.oneway.vn/post_content/2022/07/21/file-1658342005830-resized.jpg"}
              />
              <div>
                <p className="font-semibold">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-gray-500">@{user.username}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RightPart;
