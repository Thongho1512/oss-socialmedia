import React, { useState, useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import axios from "axios";
import KeyboardBackspaceIcon from "@mui/icons-material/KeyboardBackspace";
import { Avatar, Button } from "@mui/material";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import TripleTCard from "../HomeSection/TripleTCard";
import ProfileModal from "./ProfileModal";

const Profile = () => {
  const { identifier } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Khai báo các state cần thiết
  const [userData, setUserData] = useState(null);
  const [userPosts, setUserPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openProfileModal, setOpenProfileModal] = useState(false);
  const [tabValue, setTabValue] = useState("1");

  // Xác định userId dựa trên nguồn gọi
  const getUserId = () => {
    if (location.state?.from === "rightpart") {
      return location.state.userId;
    } else {
      return localStorage.getItem("user_id");
    }
  };

  const userId = getUserId();
  const isCurrentUser = userId === localStorage.getItem("user_id");

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        const accessToken = localStorage.getItem("access_token");
        
        const response = await axios.get(
          `http://localhost:8080/api/v1/users/${userId}`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );

        if (response.data && response.data.Status === 200) {
          setUserData(response.data.Data);
          // TODO: Fetch posts của user nếu cần
        }
        
        setLoading(false);
      } catch (error) {
        console.error("Lỗi khi tải thông tin người dùng:", error);
        setError(error.message);
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  const handleBack = () => navigate(-1);
  const handleOpenProfileModel = () => setOpenProfileModal(true);
  const handleClose = () => setOpenProfileModal(false);
  const handleFollowUser = () => {
    console.log("follow user");
  };
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  if (loading) return <div>Đang tải...</div>;
  if (error) return <div>Lỗi: {error}</div>;

  return (
    <div>
      <section
        className={
          " bg-white z-50 flex items-center sticky top-0 bg-opacity-95"
        }
      >
        <KeyboardBackspaceIcon
          className="cursor-pointer"
          onClick={handleBack}
        />
        <h1 className="py-5 text-xl font-bold opacity-90 ml-5">
          Welcome to the Profile Page
        </h1>
      </section>
      <section>
        <img
          className="w-[100%] h-[15rem] object-cover"
          src={
            userData?.avatarUrl ||
            "https://static.oneway.vn/post_content/2022/07/21/file-1658342005830-resized.jpg"
          }
          alt=""
        />
      </section>
      <section className="pl-6">
        <div className="flex justify-between items-start mt-5 h-[5rem] ">
          <Avatar
            className="transform -translate-y-24"
            alt={userData?.username || "user"}
            src={
              userData?.avatarUrl ||
              "https://static.oneway.vn/post_content/2022/07/21/file-1658342005830-resized.jpg"
            }
            sx={{ width: "10rem", height: "10rem", border: "4px solid white" }}
          />
          {isCurrentUser ? (
            <Button
              onClick={handleOpenProfileModel}
              variant="contained"
              sx={{ borderRadius: "20px" }}
            >
              Edit Profile
            </Button>
          ) : (
            <Button
              onClick={handleFollowUser}
              variant="contained"
              sx={{ borderRadius: "20px" }}
            >
              {isCurrentUser ? "Unfollow" : "Follow"}
            </Button>
          )}
        </div>
        <div>
          <div className="flex items-center">
            <h1 className="font-bold text-lg">
              {userData?.firstName} {userData?.lastName}
            </h1>
          </div>
          <h1 className="text-gray-500">@{userData?.username}</h1>
        </div>
        <div className=" mt-2 space-y-3">
          <p>{userData?.bio || "No bio available"}</p>
          <div className="py-1 flex space-x-5">
            <div className="flex items-center text-gray-500 ">
              <BusinessCenterIcon />
              <p className="ml-2"> Education </p>
            </div>
            <div className="flex  items-center  text-gray-500 ">
              <LocationOnIcon />
              <p className="ml-2"> Ho Chi Minh </p>
            </div>
            <div className="flex  items-center  text-gray-500 ">
              <CalendarMonthIcon />
              <p className="ml-2">
                Joined {new Date(userData?.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-5">
            <div className="flex items-center space-x-1 font-semibold">
              <span>{userData?.following_count}</span>
              <span className="text-gray-500">Following</span>
            </div>

            <div className="flex items-center space-x-1 font-semibold">
              <span>{userData?.follower_count}</span>
              <span className="text-gray-500">Followers</span>
            </div>
          </div>
        </div>
      </section>
      <section className="py-5">
        <Box sx={{ width: "100%", typography: "body1" }}>
          <TabContext value={tabValue}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <TabList
                onChange={handleTabChange}
                aria-label="lab API tabs example"
              >
                <Tab label="Posted" value="1" />
                <Tab label="Friend" value="2" />
                <Tab label="Likes" value="3" />
              </TabList>
            </Box>
            <TabPanel value="1">
              {userPosts.map((post) => (
                <TripleTCard key={post.id} post={post} />
              ))}
            </TabPanel>
            <TabPanel value="2">Item Two</TabPanel>
            <TabPanel value="3">Item Three</TabPanel>
          </TabContext>
        </Box>
      </section>
      <section>
        <ProfileModal handleClose={handleClose} open={openProfileModal} />
      </section>
    </div>
  );
};

export default Profile;
