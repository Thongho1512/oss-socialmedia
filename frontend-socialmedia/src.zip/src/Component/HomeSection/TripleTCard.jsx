import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Avatar } from "@mui/material";
import { Button, MenuItem, Menu } from "@mui/material";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import ReplyModal from "./ReplyModal";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import RepeatIcon from "@mui/icons-material/Repeat";
import { FavoriteOutlined } from "@mui/icons-material";
import FavoriteIcon from "@mui/icons-material/Favorite";
import BarChartIcon from "@mui/icons-material/BarChart";
import FileUploadIcon from "@mui/icons-material/FileUpload";

const TripleTCard = ({ post }) => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const [openReplyModal, setOpenReplyModal] = useState(false);
  const handleOpenReplyModel = () => setOpenReplyModal(true);
  const handleCloseReplyModal = () => setOpenReplyModal(false);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleDeleteTripleT = () => {
    console.log("delete tripleT");
    handleClose();
  };

  const handleCreateTripleT = () => {
    console.log("handle create retweet");
  };

  const handleLikeTipleT = () => {
    console.log("handle like tweet");
  };

  if (!post) {
    return null;
  }

  return (
    <div className="flex space-x-5">
      <Avatar
        onClick={() => navigate(`/profile/${post.userId}`)}
        className="cursor-pointer"
        alt="username"
        src="https://yt3.ggpht.com/MKAbGjzzrPfP1n1NH9wNHSN9HR3dTugpNEpg5bBGvznkWKuGU5xPP7ckH0hBqGl4V3FEXH_B=s48-c-k-c0x00ffffff-no-rj"
      />
      <div className="w-full">
        <div className="flex justify-between item-center">
          <div className="flex cursor-pointer items-center space-x-2">
            <span className="font-semibold">Thắng Gấp</span>
            <span className="text-gray-600">
              @thanggap . {new Date(post.createdAt).toLocaleDateString()}
            </span>
          </div>
          <div>
            <Button
              id="basic-button"
              aria-controls={open ? "basic-menu" : undefined}
              aria-haspopup="true"
              aria-expanded={open ? "true" : undefined}
              onClick={handleClick}
            >
              <MoreHorizIcon />
            </Button>
            <Menu
              id="basic-menu"
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              MenuListProps={{
                "aria-labelledby": "basic-button",
              }}
            >
              <MenuItem onClick={handleDeleteTripleT}>Delete TripleT</MenuItem>
            </Menu>
          </div>
        </div>
        <div className="mt-2">
          <div
            onClick={() => navigate(`/triplet/${post.id}`)}
            className="cursor-pointer"
          >
            <p className="mb-2 p-0">{post.caption}</p>
            {post.media && post.media.length > 0 && (
              <div className="grid gap-2 grid-cols-1">
                {post.media.map((media, index) => (
                  <img
                    key={index}
                    src={`http://localhost:8080/${media.url}`}
                    alt={`Post media ${index}`}
                    className="w-[28rem] border border-gray-300 p-5 rounded-md"
                  />
                ))}
              </div>
            )}
          </div>
          <div className="py-5 flex flex-wrap justify-between items-center">
            <div className="space-x-3 flex items-center text-gray-600">
              <ChatBubbleOutlineIcon
                className="cursor-pointer"
                onClick={handleOpenReplyModel}
              />
              <p>{post.commentCount}</p>
            </div>

            <div
              className={`${true ? "text-pink-600" : "text-gray-600"} space-x-3 flex items-center`}
            >
              <RepeatIcon
                onClick={handleCreateTripleT}
                className="cursor-pointer"
              />
              <p>{post.shareCount}</p>
            </div>

            <div
              className={`${true ? "text-pink-600" : "text-gray-600"} space-x-3 flex items-center`}
            >
              {true ? (
                <FavoriteIcon
                  onClick={handleLikeTipleT}
                  className="cursor-pointer"
                />
              ) : (
                <FavoriteOutlined
                  onClick={handleLikeTipleT}
                  className="cursor-pointer"
                />
              )}
              <p>{post.likeCount}</p>
            </div>

            <div className="space-x-3 flex items-center text-gray-600">
              <BarChartIcon
                className="cursor-pointer"
                onClick={handleOpenReplyModel}
              />
              <p>4300</p>
            </div>

            <div className="space-x-3 flex items-center text-gray-600">
              <FileUploadIcon
                className="cursor-pointer"
                onClick={handleOpenReplyModel}
              />
            </div>
          </div>
        </div>
      </div>

      <section>
        <ReplyModal open={openReplyModal} handleClose={handleCloseReplyModal} />
      </section>
    </div>
  );
};

export default TripleTCard;
