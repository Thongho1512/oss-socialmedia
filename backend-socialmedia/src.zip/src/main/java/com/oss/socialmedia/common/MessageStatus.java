package com.oss.socialmedia.common;

public enum MessageStatus {
    SENT, DELIVERED, READ
}
