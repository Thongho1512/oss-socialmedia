package com.oss.socialmedia.repository.custom;

public interface CustomRoleRepository {
    void deleteElementPermissionInRole( String req);
}
