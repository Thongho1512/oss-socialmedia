package com.oss.socialmedia.common;

public enum Gender {
    MALE, FEMALE, OTHER
}
