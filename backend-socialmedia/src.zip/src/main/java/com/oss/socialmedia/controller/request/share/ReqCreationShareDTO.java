package com.oss.socialmedia.controller.request.share;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ReqCreationShareDTO {
    private String content;
    private String postId;
}
