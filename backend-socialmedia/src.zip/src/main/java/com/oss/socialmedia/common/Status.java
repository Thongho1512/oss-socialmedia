package com.oss.socialmedia.common;

public enum Status {
    NONE, ACTIVE, INACTIVE
}
